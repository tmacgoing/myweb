var express      = require('express');
var session      = require('express-session');            // session中间件
var path         = require('path');
var favicon      = require('serve-favicon');
var logger       = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser   = require('body-parser');
var MongoStore   = require('connect-mongo')(session);      //将 session 存储于 mongodb，结合 express-session 使用
var flash        = require('connect-flash');               // 页面通知提示的中间件，基于 session 实现
var partials     = require('express-partials');
 

var settings     = require('./settings'); 
var index        = require('./routes/index');
var users        = require('./routes/users');


var app = express();

   //设置图片存放路径
//app.set('photos', __dirname + '/public/photos');

   //设置模板目录
app.set('views', path.join(__dirname, 'views')); 
   // 设置模板引擎为 ejs
app.set('view engine', 'ejs');  
app.use(partials());
   // uncomment after placing your favicon in /public
   //app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
   //cookie解析的中间件
app.use(cookieParser());
   // express.static是内置的中间件
   // express.static(root,[options]) 这个函数是基于伪静态,并负责提供静态资产如HTML文件,图片,等等。
   // root参数指定静态文件的根目录
app.use(express.static(path.join(__dirname, 'public')));
   // flash中间件，用来显示通知信息
app.use(flash());
   // session中间件
   // 提供会话支持，设置它的store参数为MongoStore实例，把会话信息存储到数据库中去，以避免数据丢失
app.use(session ({
    resave:false,            
    saveUninitialized: true,
    secret: settings.cookieSecret,
    store: new MongoStore({    
       //db: settings.db   
       url: 'mongodb://localhost/'+ settings.db,
       autoRemove:'native'
      })
  }));

   // 添加模板必需的三个变量
app.use(function(req, res, next){
    //console.log("app.usr local");
    res.locals.user = req.session.user;
    res.locals.post = req.session.post;
    var error = req.flash('error');
    res.locals.error = error.length ? error : null;
   
    var success = req.flash('success');
    res.locals.success = success.length ? success : null;
    next();
  });

app.use('/', index);
app.use('/users', users);



     // catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

     // error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
