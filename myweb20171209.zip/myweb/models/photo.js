// var mongoose = require('mongoose');
//     mongoose.connect('mongodb://localhost/photo_app'); //连接本地photo_app数据库  

// var schema = new mongoose.Schema({
//     name: String,
//     path: String
//   });
  
// module.exports = mongoose.model('photo', schema);
var mongodb = require('./db');


/*
 * 集合`posts`的文档`Post`构造函数
 * @param {String} username: 发言人的名字
 * @param {String} post: 发言内容
 * @param {String} time: 发言时间
 */
function Photo(username,photo_name,path,time) {
	this.user = username;
	this.photo_name = photo_name;
    this.path = path;

    if(time) {
		this.time = time;
	} else {
		this.time = new Date();
	}
};

module.exports = Photo;

/*
 * 保存一条发言到数据库
 * @param {Function} callback: 执行完数据库操作的应该执行的回调函数
 */
Photo.prototype.save = function save(callback) {
	var photo = {
		user: this.user,
		photo_name: this.photo_name,
		path: this.path,
        time: this.time,
	};
	mongodb.open(function(err, db) {
		if (err) {
			return callback(err);
		}

		db.collection('photos', function(err, collection) {
			if (err) {
				mongodb.close();
				return callback(err);
			}
			collection.insert(photo, {safe: true}, function(err, photo) {
				mongodb.close();
				callback(err, photo);
			});
		});
	});
};

/*
 * 查询一个用户的所有发言
 * @param {String} username: 需要查询的用户的名字 
 * @param {Function} callback: 执行完数据库操作的应该执行的回调函数
 */
Photo.get = function get(username, callback) {
	mongodb.open(function(err, db) {
		if (err) {
			return callback(err);
		}

		db.collection('photos', function(err, collection) {
			if (err) {
				mongodb.close();
				return callback(err);
			}
			var query = {};
			if (username) {
				query.user = username;
			}
			collection.find(query).sort({time: -1}).toArray(function(err, docs) {
				mongodb.close();
				if (err) {
					callback(err, null);
				}
                //
				var photos = [];
				docs.forEach(function(doc, index) {
					var photo = new Photo(doc.user, doc.photo_name,doc.path,doc.time);
					photos.push(photo);
				});
				callback(null, photos);
			});
		});
	});
};