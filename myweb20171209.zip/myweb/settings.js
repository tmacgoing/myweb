module.exports = {
  cookieSecret: 'microblog_myweb',
  db: 'myweb_mongoDB',
  host: 'localhost',
  port: 27017
}; 
