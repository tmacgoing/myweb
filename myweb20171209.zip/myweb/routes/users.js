var express = require('express');
var router  = express.Router();

var crypto  = require('crypto'); 
var User    = require('../models/user.js'); 
var Post    = require('../models/post.js');

var Photo      = require('../models/photo.js');
var formidable = require('formidable');
var fs         = require('fs');	
var sd         = require("silly-datetime");

/**
 * 点击 用户注册 按钮进入 注册页面 的代码 ；
 */
router.get('/reg', checkNotLogin);
router.get('/reg', function(req, res, next) {
    res.render('reg', { 
      title: '用户注册' 
    });   
});

/**
 * 点击  注册页面 中 注册按钮 的代码 ；
 */
router.post('/reg', checkNotLogin);
router.post('/reg', function(req, res, next) {
    console.log('username:' + req.body['username']);
    console.log('password:' + req.body['password']);
    console.log('password-repeat:' + req.body['password-repeat']);
   //检验用户名是否为空
   if ((req.body['username'] == '') || (req.body['password-repeat'] == '')|| (req.body['password'] == '')) { 
     req.flash('error', '用户名、口令 及 重复输入的口令 不能为空'); 
     return res.redirect('/users/reg');
   }
   //检验用户两次输入的口令是否一致 
   if (req.body['password-repeat'] != req.body['password']) { 
     req.flash('error', '两次输入的口令不一致'); 
     return res.redirect('/users/reg'); 
    } 
  //生成口令的散列值 
  var md5 = crypto.createHash('md5'); 
  var password = md5.update(req.body.password).digest('base64'); 
   
  var newUser = new User({ 
    name: req.body.username, 
    password: password, 
  }); 
  //检查用户名是否已经存在 
   User.get(newUser.name, function(err, user) { 
    if (user) 
    err = 'Username already exists.'; 
    if (err) { 
    req.flash('error', err); 
    return res.redirect('/users/reg'); 
  } 
  //如果不存在则新增用户 
   newUser.save(function(err) { 
    if (err) { 
      req.flash('error', err); 
      return res.redirect('/users/reg'); 
    } 
    req.session.user = newUser; 
    req.flash('success', '注册成功'); 
    res.redirect('/'); 
   }); 
  }); 
});

/**
 * 点击 首页———— 登入按钮 进入 登录页面  的代码 ；
 */
router.get('/login', checkNotLogin); 
router.get('/login', function(req, res, next) {
 // res.send('respond with a resource get login');
 res.render('login', {
   title: '用戶登入',
  });
});

/**
 * 点击 登录页面—————— 登入按钮  的代码 ；
 */

router.post('/login', checkNotLogin);
router.post('/login', function(req, res, next) {
  //res.send('respond with a resource post login');
  //生成口令的散列值 
  console.log("进入 login");
 var md5 = crypto.createHash('md5'); 
 var password = md5.update(req.body.password).digest('base64'); 
  
 User.get(req.body.username, function(err, user) { 
   if (!user) { 
     req.flash('error', '用户不存在'); 
     console.log("用户不存在");
     return res.redirect('/users/login'); 
   } 
   if (user.password != password) { 
     req.flash('error', '用户口令错误'); 
     console.log("用户口令错误");
     return res.redirect('/users/login'); 
   } 
   req.session.user = user; 
   req.flash('success', '登入成功'); 
   console.log("登入成功,返回首页！");
   res.redirect('/'); 
 }); 
});

/**
 * 点击  首页————登出按钮  的代码 ；
 */

router.get('/logout', checkLogin); 
router.get('/logout', function(req, res, next) {
  //res.send('respond with a resource get logout');
  req.session.user = null; 
  req.flash('success', '登出成功'); 
  res.redirect('/'); 
}); 

function checkNotLogin(req, res, next) {
  if (req.session.user) {
    req.flash('error', '已登入');
    return res.redirect('/users/');
  }
  next();
}

function checkLogin(req, res, next) {
  if (!req.session.user) {
    req.flash('error', '未登入');
    return res.redirect('/users/login');
  }
  next();
}


// 发言路由
router.post("/post",checkLogin);
router.post("/post",function(req,res) {
  console.log("进入post /post代码段！");
	var currentUser = req.session.user;
	var post = new Post(currentUser.name, req.body.post);
	post.save(function(err) {
		if (err) {
			req.flash('error', err);
			return res.redirect('/');
		}
		req.flash('success', '发表成功');
		res.redirect('/users/u/' + currentUser.name);
	});
});


router.get("/u/:user",function(req,res) {
	User.get(req.params.user, function(err, user) {
		if (!user) {
			req.flash('error', '用户不存在');
			return res.redirect('/');
		}
		Post.get(user.name, function(err, posts) {
			if (err) {
				req.flash('error', err);
				return res.redirect('/');
			}
			res.render('user', {
				title: user.name,
				posts: posts,
			});
		});
	});
});

router.post('/upload_photos', checkLogin); 
router.post('/upload_photos', function(req, res, next) {
    console.log("进入 图片上传 代码段！");
    res.render('photos/upload', { 
      title: '请上传图片' 
    });  
});

router.post('/photos_index', checkLogin); 
router.post('/photos_index', function(req, res, next) {
    console.log("进入 图片展示 代码段！");
    Photo.get(req.params.user, function(err, photos) {
      if (err) {
        req.flash('error', err);
        //return res.redirect('/');
      }
        res.render('photos/index', {
       title: '图片展示',
       photos: photos,
      });
    });
});

router.post('/upload', checkLogin); 
router.post('/upload', function(req, res, next) {
    console.log("进入 图片确认提交 代码段！");
    var form = new formidable.IncomingForm();   //创建上传表单
    form.encoding = 'utf-8';		//设置编辑
    form.uploadDir = 'public' + '/photos/';	 //设置上传目录
    form.keepExtensions = true;	 //保留后缀
    form.maxFieldsSize = 2 * 1024 * 1024;   //文件大小
  
    form.parse(req, function (err, fields, files) {
  
      if (err) {
        req.flash('error', err);
        console.log("err！");
				//return res.redirect('/');
      }
  
      // 限制文件大小 单位默认字节 这里限制大小为2m
      if (files.fulAvatar.size > form.maxFieldsSize) {
        fs.unlink(files.fulAvatar.path)
        req.flash('error', '图片应小于2M');
        console.log("图片应小于2M!");
        //return res.redirect('/');
      }
  
      var extName = '';  //后缀名
      switch (files.fulAvatar.type) {
        case 'image/pjpeg':
          extName = 'jpg';
          break;
        case 'image/jpeg':
          extName = 'jpg';
          break;
        case 'image/png':
          extName = 'png';
          break;
        case 'image/x-png':
          extName = 'png';
          break;
      }
  
      if (extName.length == 0) {
        req.flash('error', '只支持png和jpg格式图片');
        console.log("只支持png和jpg格式图片!");
        //return res.redirect('/');
      }
  
      //使用第三方模块silly-datetime
      var t = sd.format(new Date(), 'YYYYMMDDHHmmss');
      //生成随机数
      var ran = parseInt(Math.random() * 8999 + 10000);
  
      // 生成新图片名称
      var pos = files.fulAvatar.name.lastIndexOf(".");
      var avatarName = files.fulAvatar.name.substr(0,pos) + '_' + t + '_' + ran + '.' + extName ;

      // 生成图片保存时的名称
      var save_avatarName = files.fulAvatar.name.substr(0,pos) + '_' + t + '_' + ran;

      // 新图片路径
      var newPath = form.uploadDir + avatarName;

      // 生成图片保存路径
      var save_newPath =  '/photos/' + avatarName;

      // 更改名字和路径
      fs.rename(files.fulAvatar.path, newPath, function (err) {
        if (err) {
          req.flash('error', '图片上传失败');
          console.log("图片上传失败！");
          //return res.redirect('/users/');
        }
        req.flash('success', '图片上传成功');
        console.log("图片上传成功！");
        //res.redirect('/users/photos/index');
      })
      console.log("进入 图片信息存档 代码段！");
      var currentUser = req.session.user;

      var photo = new Photo(currentUser.name, save_avatarName, save_newPath);
      photo.save(function(err) {
        if (err) {
          req.flash('error', err);
          console.log("图片信息存档失败！");
          //return res.redirect('/');
        }
        req.flash('success', '图片信息存档成功!');
        res.redirect('/users/photos/index');
      });
    });  
});

router.get('/photos/index', checkLogin); 
router.get('/photos/index', function(req, res, next) {
  console.log("上传完成后 进入 图片展示 代码段！");
    Photo.get(req.params.user, function(err, photos) {
    if (err) {
      req.flash('error', err);
       }
      res.render('photos/index', {
     title: '图片展示',
     photos: photos,
    });
  });
});

module.exports = router;
