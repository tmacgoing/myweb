var express = require('express');
var router  = express.Router();

var Post    = require("../models/post.js");

/* GET home page. */
router.get('/', function(req, res, next) {
    Post.get(null, function(err, posts) {
		if (err) {
			posts = [];
		}
		res.render('index', {
			title: 'Express myweb',
			posts: posts,
			user : req.session.user,
            success : req.flash('success').toString(),
            error : req.flash('error').toString()
		});
	});
   //在 render 一个页面时，如果不指定 Layout ，系统会自动在 view 文件夹下寻找 layout.(jade|ejs) 文件。也可以指定：layout: 'layout2'
});


module.exports = router;
